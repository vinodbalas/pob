var nappservices = angular.module('napp.services', []);

nappservices.service('SpeechRecognize', function($rootScope){

  this.recognize = function(callback) {
      var maxMatches = 1;
      var promptString = "Speak now";
      var language = "en-in";
      window.plugins.speechrecognizer.startRecognize(function(result){
          callback(result);
      }, function(errorMessage){
          console.log("Error message: " + errorMessage);
      }, maxMatches, promptString, language);
  }

  function getSupportedLanguages() {
      window.plugins.speechrecognizer.getSupportedLanguages(function(languages){
          alert(languages);
      }, function(error){
          alert("Could not retrieve the supported languages : " + error);
      });
  }
})

nappservices.directive('tabsSwipable', ['$ionicGesture', function($ionicGesture){
  //
  // make ionTabs swipable. leftswipe -> nextTab, rightswipe -> prevTab
  // Usage: just add this as an attribute in the ionTabs tag
  // <ion-tabs tabs-swipable> ... </ion-tabs>
  //
  return {
    restrict: 'A',
    require: 'ionTabs',
    link: function(scope, elm, attrs, tabsCtrl){
      var onSwipeLeft = function(){
        var target = tabsCtrl.selectedIndex() + 1;
        if(target < tabsCtrl.tabs.length){
          scope.$apply(tabsCtrl.select(target));
        }
      };
      var onSwipeRight = function(){
        var target = tabsCtrl.selectedIndex() - 1;
        if(target >= 0){
          scope.$apply(tabsCtrl.select(target));
        }
      };        
      var swipeGesture = $ionicGesture.on('swipeleft', onSwipeLeft, elm).on('swiperight', onSwipeRight);
      scope.$on('$destroy', function() {
          $ionicGesture.off(swipeGesture, 'swipeleft', onSwipeLeft);
          $ionicGesture.off(swipeGesture, 'swiperight', onSwipeRight);
      });
    }
  };
}]);

nappservices.factory('Teams', function() {
  var teams = [{
    id: 0,
    name: 'JS Core',
    members: ["sumit.gupta@servicemax.com"],
    desc: 'Awesome team!!',
    face: 'https://pbs.twimg.com/profile_images/514549811765211136/9SgAuHeY.png'
  }, {
    id: 1,
    name: 'Online Team',
    members: ["sumit.gupta@servicemax.com"],
    desc: 'Hey, it\'s me',
    face: 'https://avatars3.githubusercontent.com/u/11214?v=3&s=460'
  },{
    id: 2,
    name: 'Adam Bradleyson',
    desc: 'I should buy a boat',
    face: 'https://pbs.twimg.com/profile_images/479090794058379264/84TKj_qa.jpeg'
  }, {
    id: 3,
    name: 'Perry Governor',
    desc: 'Look at my mukluks!',
    face: 'https://pbs.twimg.com/profile_images/598205061232103424/3j5HUXMY.png'
  }, {
    id: 4,
    name: 'Mike Harrington',
    desc: 'This is wicked good ice cream.',
    face: 'https://pbs.twimg.com/profile_images/578237281384841216/R3ae1n61.png'
  },{
    id: 5,
    name: 'Adam Bradleyson',
    desc: 'I should buy a boat',
    face: 'https://pbs.twimg.com/profile_images/479090794058379264/84TKj_qa.jpeg'
  }, {
    id: 6,
    name: 'Perry Governor',
    desc: 'Look at my mukluks!',
    face: 'https://pbs.twimg.com/profile_images/598205061232103424/3j5HUXMY.png'
  }, {
    id: 7,
    name: 'Mike Harrington',
    desc: 'This is wicked good ice cream.',
    face: 'https://pbs.twimg.com/profile_images/578237281384841216/R3ae1n61.png'
  }];

  return {
    all: function() {
      return teams;
    },
    remove: function(chat) {
      teams.splice(teams.indexOf(chat), 1);
    },
    get: function(teamId) {
      for (var i = 0; i < teams.length; i++) {
        if (teams[i].id === parseInt(teamId)) {
          return teams[i];
        }
      }
      return null;
    }
  };
});

nappservices.factory('Trends', function() {
  var trends = [{
    id: 0,
    name: 'Ben Sparrow',
    desc: 'You on your way?',
    face: 'https://pbs.twimg.com/profile_images/514549811765211136/9SgAuHeY.png'
  }, {
    id: 1,
    name: 'Max Lynx',
    desc: 'Hey, it\'s me',
    face: 'https://avatars3.githubusercontent.com/u/11214?v=3&s=460'
  },{
    id: 2,
    name: 'Adam Bradleyson',
    desc: 'I should buy a boat',
    face: 'https://pbs.twimg.com/profile_images/479090794058379264/84TKj_qa.jpeg'
  }, {
    id: 3,
    name: 'Perry Governor',
    desc: 'Look at my mukluks!',
    face: 'https://pbs.twimg.com/profile_images/598205061232103424/3j5HUXMY.png'
  }, {
    id: 4,
    name: 'Mike Harrington',
    desc: 'This is wicked good ice cream.',
    face: 'https://pbs.twimg.com/profile_images/578237281384841216/R3ae1n61.png'
  },{
    id: 5,
    name: 'Adam Bradleyson',
    desc: 'I should buy a boat',
    face: 'https://pbs.twimg.com/profile_images/479090794058379264/84TKj_qa.jpeg'
  }, {
    id: 6,
    name: 'Perry Governor',
    desc: 'Look at my mukluks!',
    face: 'https://pbs.twimg.com/profile_images/598205061232103424/3j5HUXMY.png'
  }, {
    id: 7,
    name: 'Mike Harrington',
    desc: 'This is wicked good ice cream.',
    face: 'https://pbs.twimg.com/profile_images/578237281384841216/R3ae1n61.png'
  }];

  return {
    all: function() {
      return trends;
    },
    remove: function(chat) {
      trends.splice(trends.indexOf(chat), 1);
    },
    get: function(trendId) {
      for (var i = 0; i < trends.length; i++) {
        if (trends[i].id === parseInt(trendId)) {
          return trends[i];
        }
      }
      return null;
    }
  };
});

nappservices.factory('People', function() {
  var people = [{
    id: 0,
    name: 'Ben Sparrow',
    desc: 'You on your way?',
    face: 'https://pbs.twimg.com/profile_images/514549811765211136/9SgAuHeY.png'
  }, {
    id: 1,
    name: 'Max Lynx',
    desc: 'Hey, it\'s me',
    face: 'https://avatars3.githubusercontent.com/u/11214?v=3&s=460'
  },{
    id: 2,
    name: 'Adam Bradleyson',
    desc: 'I should buy a boat',
    face: 'https://pbs.twimg.com/profile_images/479090794058379264/84TKj_qa.jpeg'
  }, {
    id: 3,
    name: 'Perry Governor',
    desc: 'Look at my mukluks!',
    face: 'https://pbs.twimg.com/profile_images/598205061232103424/3j5HUXMY.png'
  }, {
    id: 4,
    name: 'Mike Harrington',
    desc: 'This is wicked good ice cream.',
    face: 'https://pbs.twimg.com/profile_images/578237281384841216/R3ae1n61.png'
  },{
    id: 5,
    name: 'Adam Bradleyson',
    desc: 'I should buy a boat',
    face: 'https://pbs.twimg.com/profile_images/479090794058379264/84TKj_qa.jpeg'
  }, {
    id: 6,
    name: 'Perry Governor',
    desc: 'Look at my mukluks!',
    face: 'https://pbs.twimg.com/profile_images/598205061232103424/3j5HUXMY.png'
  }, {
    id: 7,
    name: 'Mike Harrington',
    desc: 'This is wicked good ice cream.',
    face: 'https://pbs.twimg.com/profile_images/578237281384841216/R3ae1n61.png'
  }];

  return {
    all: function() {
      return people;
    },
    remove: function(person) {
      people.splice(people.indexOf(person), 1);
    },
    get: function(personId) {
      for (var i = 0; i < people.length; i++) {
        if (people[i].id === parseInt(personId)) {
          return people[i];
        }
      }
      return null;
    }
  };
});
